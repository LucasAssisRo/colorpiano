import PlaygroundSupport
import UIKit

let sVc = SimulationViewController()
PlaygroundPage.current.liveView = sVc

